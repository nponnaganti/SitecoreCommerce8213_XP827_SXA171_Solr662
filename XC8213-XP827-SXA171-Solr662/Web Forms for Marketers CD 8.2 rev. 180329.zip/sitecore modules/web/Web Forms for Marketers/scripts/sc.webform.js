﻿var i = 0;

if (typeof ($scw) === "undefined") {
    window.$scw = jQuery.noConflict(true);
}

(function($) {
    $.widget("sc.webform", {
        options: {
            formId: null,
            pageId: null,
            pageIndex: -1,
            fieldId: null,
            fieldValue: null,
            eventCountId: null
        },

        _create: function() {
            var self = this,
                options = this.options;
            if (options.tracking) {
                this.element.find("input[type!='submit'][type!='password'], select, textarea").filter(":not(.scWfmPassword)")
                    .bind('focus', function(e) { self.onFocusField(e, this) })
                    .bind('blur change', function(e) {
                        self.onBlurField(e, this)
                    });


                var agt = navigator.userAgent.toLowerCase();

                if (((agt.indexOf("msie") != -1) && (agt.indexOf("opera") == -1)) || (agt.indexOf("chrome") != -1)) {
                    this.element.find("input[type='submit']").bind('click', function(e) {
                        document.activeElement.blur();
                    })
                }

                this.element.find("select")
                    .change(function() { $scw.webform.controls.updateAnalyticsListValue(this) });

                this.element.find("input[type='checkbox'], input[type='radio']")
                    .click(function() { $scw.webform.controls.updateAnalyticsListValue(this) });
            }

            this.element.find(".scfDatePickerTextBox").each(function() { $scw.webform.controls.datePicker(this) });
        },

        onFocusField: function(e, element) {

            var owner = $scw.webform.utils.getAncestorByAttribute(element);

            if (owner.length > 0) {
                var fullfieldID = $scw.webform.utils.getCssValue(owner[0], 'fieldid');
                var options = this.options;
                if (options.fieldId != fullfieldID) {
                    var hiddenValue = $scw("#" + owner.attr('id') + "_complexvalue");
                    var value = null;

                    if (hiddenValue.length == 0 && element.type == "checkbox") {
                        value = element.checked ? "1" : "0";
                    } else {
                        value = (hiddenValue.length == 0 ? $scw(element).val() || element.value : hiddenValue.val()).toString();
                    }

                    options.fieldId = fullfieldID;
                    options.fieldValue = value;
                }
            }
        },

        onBlurField: function(e, element) {
            var target = e.explicitOriginalTarget || e.srcElement || e.activeElement;

            var owner = $scw.webform.utils.getAncestorByAttribute(element);

            if (owner.length > 0) {
                var options = this.options;
                var fullfieldID = $scw.webform.utils.getCssValue(owner[0], 'fieldid');

                var hiddenValue = $scw("#" + owner.attr('id') + "_complexvalue");

                if (hiddenValue.length == 0 && element.type == "checkbox") {
                    value = element.checked ? "1" : "0";
                } else {
                    value = (hiddenValue.length == 0 ? $scw(element).val() || element.value : hiddenValue.val()).toString();
                }

                if (options.fieldId != fullfieldID || (options.fieldId == fullfieldID && options.fieldValue != value)) {
                    options.fieldId = fullfieldID;
                    options.fieldValue = value;

                    if (element.type == "password" || $scw(element).hasClass("scWfmPassword")) {
                        value = "schidden";
                    }
                    var clientEvent = this._getEvent(fullfieldID, "Field Completed", value.replace(/<schidden>.*<\/schidden>/, "schidden"));

                    var validationevent = this._checkClientValidation(element);;
                    this._trackEvents($scw.merge([clientEvent], validationevent));
                }
            }
        },

        _checkClientValidation: function(element) {
            var tracker = this;
            var events = [];
            if (element.Validators != null) {
                $scw(element.Validators).each(function() {

                    var validator = $scw(this);

                    if (validator[0].isvalid == false) {
                        var clientEvent = tracker._getEvent(
                            $scw.webform.utils.getCssValue(validator[0], 'fieldid'),
                            $scw.webform.utils.getCssValue(validator[0], 'trackevent'),
                            validator[0].errormessage);
                        events.push(clientEvent);
                    }
                });
            }
            return events;
        },

        _trackEvents: function(events) {
            $scw.ajax({
                type: 'POST',
                url: "/sitecore modules/web/Web Forms for Marketers/Tracking.aspx",
                data: { track: JSON.stringify(events) },
                dataType: 'json'
            });
        },

        _getEvent: function(fieldid, type, value) {
            var options = this.options;
            var eventCount = $scw("#" + options.eventCountId).val();
            ++eventCount;
            $scw("#" + options.eventCountId).val(eventCount);

            return {
                'fieldId': fieldid,
                'type': type,
                'value': value,
                'pageIndex': options.pageIndex,
                'formId': options.formId,
                'pageId': options.pageId,
                'ticks': eventCount
            };
        },

        scrollTo: function(elementId, focusElementId) {

            if (elementId != null && elementId != '') {
                $scw(window).scrollTop($scw('#' + elementId).position().top);
            }

            if (focusElementId != null && focusElementId != '' && !$scw('#' + focusElementId).attr('readonly')) {
                $scw('#' + focusElementId).focus();
            }
        },

        updateSubmitData: function(formId) {

            if ($scw.webform.lastSubmit != null && $scw.webform.lastSubmit != '') {
                var ctrl = $scw("#" + $scw.webform.lastSubmit);
                if (ctrl.length > 0) {
                    var submit = ctrl[0];
                    if (submit.id != null && submit.id.indexOf(formId) > -1) {
                        submit.disabled = true;
                        var hidden = document.createElement('input');
                        hidden.setAttribute('type', 'hidden');
                        hidden.setAttribute('id', submit.id);
                        hidden.setAttribute('name', submit.name);
                        hidden.setAttribute('value', ctrl.val());
                        try {
                            ctrl.parents('form:first').append(hidden);
                        } catch (err) {
                        }
                    }
                }
            }
        },

        destroy: function() {
            this.element.find("input[type!='submit'], select, textarea").unbind('focus blur');
            this.element.find("select").unbind('select');
            this.element.find("input[type='checkbox'], input[type='radio']").unbind('click');
        }
    })
})($scw);

$scw.extend({
    webform: {
        lastSubmit: ''
    }
});

$scw.extend($scw.webform, {
    utils: {
        getAncestorByAttribute: function(element, skipMe, attributeKey) {
            if (element != null) {
                var skipElement = (skipMe || false),
                    attributeName = (attributeKey || "fieldid");

                if (!skipElement && element.className != null && element.className.indexOf(" " + attributeName) >= 0) {
                    return $scw(element);
                }

                var parent = $scw(element).parent('[class*="' + attributeName + '"]');
                if (parent.length > 0) {
                    return parent;
                }

                var ancestors = $scw(element).parents();
                ancestors.each(function() {
                    if (this.className != null && this.className != '' &&
                        this.className.indexOf(attributeName) > -1) {
                        parent = this;
                        return;
                    }
                })

                if (parent != null) {
                    return $scw(parent);
                }

                return $scw(element).parent("[" + attributeName + "]")
            }
        },

        getCssValue: function(element, attributeName) {
            var pos = element.className.indexOf(" " + attributeName);
            if (element.className.indexOf(attributeName) == 0) {
                pos = 0;
            } else {
                ++pos;
            }

            if (pos > -1) {
                pos = pos + attributeName.length + 1;
                try {
                    var start = pos;
                    var end = element.className.indexOf(" ", pos);
                    if (end == -1) {
                        end = element.className.length;
                    }
                    return unescape(element.className.substring(start, end).replace(/\+/g, " "));
                } catch (ex) {

                }
            }
            return $scw(element).attr(attributeName);
        },

        getDescendantByAttribute: function(element, attributeKey) {

            var attributeName = attributeKey || "fieldid";

            if (element != null) {
                if (element.className != null && element.className.indexOf(" " + attributeName) >= 0) {
                    return $scw(element);
                }

                var descendant = $scw(element).find('[class*="' + attributeName + '"]');
                if (descendant.length > 0) {
                    return descendant;
                }

                var descendants = $scw(element).find('*');
                descendants.each(function() {
                    if (this.className != null && this.className != '' &&
                        this.className.indexOf(attributeName) > -1) {
                        descendant = this;
                        return;
                    }
                })

                if (descendant != null) {
                    return $scw(descendant);
                }

                return $scw(element).find("[" + attributeName + "]");
            }
        }
    }
});

$scw.extend($scw.webform, {
    date: {
        isLeapYear: function(year) {
            var Last2Digits = year % 100
            if (Last2Digits == 0) {
                flag = year % 400
            } else {
                flag = year % 4
            }

            return flag == 0;
        },

        getDays: function(month, year) {
            var days = 31;
            switch (month) {
            case 2:
                days = (this.isLeapYear(year)) ? 29 : 28;
                break;
            case 4:
            case 6:
            case 9:
            case 11:
                days = 30;
                break;
            }

            return days;
        }
    }
});

$scw.extend($scw.webform, {
    controls: {
        datePicker: function(element) {
            var self = $scw(element).attr('readonly', 'true');
            icon = $scw("<span class='ui-icon ui-icon-calendar ui-icon-datepicker'></span>");
            self.after(icon);
            icon.click(function() {
                self.datepicker('show');
            });
        },

        updateDateSelector: function(obj) {
            var fieldItem = $scw.webform.utils.getAncestorByAttribute(obj, true);
            var id = fieldItem.attr('id');
            if ($scw("#" + id + '_month') != null && $scw("#" + id + '_year') != null) {
                var year = $scw("#" + id + '_year');
                var month = $scw("#" + id + '_month');

                if (month.length > 0 && year.length > 0) {
                    var days = $scw.webform.date.getDays(parseInt(month[0].selectedIndex + 1, 10),
                        parseInt(year[0].selectedIndex, 10));
                    var selectDays = $scw("#" + id + '_day');
                    if (selectDays.length > 0) {
                        selectDays = selectDays[0];

                        while (selectDays.length > days) {
                            selectDays.remove(selectDays.length - 1);
                        }

                        while (selectDays.length < days) {
                            var option = document.createElement('option');
                            option.text = selectDays.length + 1;
                            option.value = selectDays.length + 1;
                            try {
                                selectDays.add(option, null);
                            } catch (ex) {
                                selectDays.add(option);
                            }
                        }
                    }
                }
            }

            this.updateAnalyticsDataValue(obj);
        },

        updateAnalyticsDataValue: function(obj) {
            var fieldItem = $scw.webform.utils.getAncestorByAttribute(obj, true);
            if (fieldItem.length > 0) {
                var id = fieldItem.attr('id');

                var year = $scw("#" + id + '_year');
                var month = $scw("#" + id + '_month');
                var day = $scw("#" + id + '_day');
                if (year.length > 0 && month.length > 0 && day.length > 0) {
                    var monthValue = month.val();
                    if (monthValue.length == 1) {
                        monthValue = "0" + monthValue;
                    }

                    var dayValue = day.val();
                    if (dayValue.length == 1) {
                        dayValue = "0" + dayValue;
                    }

                    $scw("#" + id + "_complexvalue").val(year.val() + monthValue + dayValue + "T000000");
                }
            }
        },

        updateAnalyticsListValue: function(obj) {

            var fieldItem = $scw.webform.utils.getAncestorByAttribute(obj, true);
            if (fieldItem.length > 0) {
                var id = fieldItem.attr('id');

                var complexvalue = "";
                var used = false;
                $scw("#" + id + " input[type='radio'], #" + id + " input[type='checkbox']").each(function() {
                    used = true;
                    var value = $scw(this).val()

                    if (value == null && this.type != "checkbox") {
                        value = this.value;
                    }

                    if (this.type == "checkbox") {
                        if (this.checked) {
                            if (value == "on") {
                                var label = $scw(this).next("label[for]:first");
                                complexvalue += (", " + (label.length > 0 ? label.html() : this.id))
                            } else {
                                complexvalue += (", " + value);
                            }
                        }
                    } else {
                        if (this.type == "radio") {
                            if (this.checked) {
                                complexvalue += (", " + value);
                            }
                        } else {
                            complexvalue += (", " + value);
                        }
                    }
                });
                if (used) $scw("#" + id + "_complexvalue").val(complexvalue.substr(2, complexvalue.length));
            }
        },

        attachCaptchaHandler: function(playButtonId, imageHolderId, playerHolderId) {
            var audio = $scw("#" + playButtonId);
            if (audio.length > 0) {
                var link = $scw("#" + imageHolderId).children().next().children();
                if (link.length > 0) {
                    audio.attr('href', link.attr('src').replace('CaptchaImage.axd', 'CaptchaAudio.axd'));
                    audio[0].onclick = function() { return false; };
                    var player = $scw("#" + playerHolderId);
                    audio.bind('click', function(e) {
                        var embedCode = "<EMBED SRC=" + $scw(this).attr('href') + " HIDDEN='true' AUTOSTART='true' />";
                        player.html('').html(embedCode);
                        e.stopImmediatePropagation();
                        e.preventDefault();
                    });
                }
            }
            return false;
        }
    }
});

$scw.extend($scw.webform, {
    validators: {
        validateCreditCard: function(obj, args, cardType) {
            var cardType = $scw.webform.utils.getCssValue(obj, "cardTypeValue");
            var validationExpression = $scw.webform.utils.getCssValue(obj, "validationExpression");

            var fieldItem = $scw.webform.utils.getAncestorByAttribute(obj, true);
            if (fieldItem.length > 0) {
                var id = fieldItem.id;

                var cardTypeObj = $scw.webform.utils.getDescendantByAttribute(fieldItem[0], "cardType.");

                if (cardTypeObj.length > 0 && cardTypeObj.val() == cardType) {
                    var regex = new RegExp(unescape(validationExpression), "g")
                    var regex2 = new RegExp(unescape(unescape(validationExpression)), "g")
                    args.IsValid = regex.test(args.Value) || regex2.test(args.Value);
                    return;
                }
            }
            args.IsValid = true;
        },

        validatePasswordConfirmation: function(obj, args) {

        },

        numberRange: function(obj, args) {
            var ctrl = $scw(obj);
            if (ctrl.length > 0) {
                var min = $scw.webform.utils.getCssValue(ctrl[0], 'minimum');
                var max = $scw.webform.utils.getCssValue(ctrl[0], "maximum");

                if (min.toString() != 'NaN' && max.toString() != 'NaN') {
                    if (args != null && args.Value != null && args.Value != "") {
                        if (max != null && max != "" && min != null && min != "") {
                            max = parseFloat(max);
                            min = parseFloat(min);

                            var value = parseFloat(args.Value);
                            if (value.toString() != 'NaN' && !(max >= value && value >= min)) {
                                args.IsValid = false;
                                return;
                            }
                        }
                    }
                }
            }
            args.IsValid = true;
        },

        dateRange: function(obj, args) {

            var ctrl = $scw(obj);
            if (ctrl.length > 0) {

                var min = $scw.webform.utils.getCssValue(ctrl[0], 'startdate');
                var max = $scw.webform.utils.getCssValue(ctrl[0], "enddate");

                var year = $scw("#" + ctrl[0].controltovalidate + "_year").val();
                var month = $scw("#" + ctrl[0].controltovalidate + "_month").val();
                var day = $scw("#" + ctrl[0].controltovalidate + "_day").val();

                var value = '';

                if (year.length == 2) {
                    value += "20" + year;
                } else {
                    value += year;
                }

                if (month.length == 1) {
                    value += "0" + month;
                } else {
                    value += month;
                }

                if (day.length == 1) {
                    value += "0" + day;
                } else {
                    value += day;
                }

                value += "T120000";

                if (args != null && args.Value != null && args.Value != "") {
                    if (max != null && max != "" && min != null && min != "") {

                        if (!(max >= value && value >= min)) {
                            args.IsValid = false;
                            return;
                        }
                    }
                }
            }
            args.IsValid = true;
        },

        setFocusToFirstNotValid: function(validationGroup) {
            if (typeof (Page_ClientValidate) == 'function' && !(typeof Page_Validators === 'undefined')) {
                Page_InvalidControlToBeFocused = null;
                for (var i = 0; i < Page_Validators.length; i++) {
                    var val = Page_Validators[i];
                    ValidatorValidate(val, validationGroup, null);
                    if (!val.isvalid) {
                        ValidatorSetFocus(val, null);
                        $scw(window).scrollTop($scw("#" + val.controltovalidate).position().top);
                        return false;
                    }
                }
            }

            return true;
        }
    }
});

$scw.extend($scw.webform, {
    pageeditor: {
        edit: function(renderingId, referenceId, formId) {
            var element = $scw('.sc-webform-openeditor');
            if (element.length > 0) {
                element.parents('.scPageDesignerControl:first').css('opacity', '1');
                element.remove();
                Sitecore.PageModes.PageEditor.postRequest('forms:edit(checksave=0,renderingId=' + renderingId +
                    ',referenceId=' + referenceId +
                    ',id=' + formId + ')', null, true);
            }
        }
    }
});